import UIKit
import WebKit
import UniformTypeIdentifiers

// MARK: - WeakScriptMessageHandler (prevents retain cycle)
private class WeakScriptMessageHandler: NSObject, WKScriptMessageHandler {
    weak var target: WKScriptMessageHandler?
    init(_ target: WKScriptMessageHandler) { self.target = target }
    func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
        target?.userContentController(c, didReceive: m)
    }
}

// MARK: - ViewController
class ViewController: UIViewController {

    private var webView: WKWebView!
    private let bgColor = UIColor(red: 0.008, green: 0.051, blue: 0.086, alpha: 1.0)

    // MARK: Status bar
    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }
    override var prefersStatusBarHidden: Bool { false }

    // MARK: Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = bgColor
        buildWebView()
        loadApp()
    }

    // MARK: Build WebView
    private func buildWebView() {
        let config = WKWebViewConfiguration()

        // Persistent localStorage / IndexedDB — survives app restarts
        config.websiteDataStore = .default()
        config.preferences.javaScriptEnabled = true
        config.allowsInlineMediaPlayback = true

        let ucc = WKUserContentController()
        ucc.add(WeakScriptMessageHandler(self), name: "exportBackup")
        ucc.add(WeakScriptMessageHandler(self), name: "importBackup")

        // Inject iOS bridge before any page script runs
        let bridge = WKUserScript(
            source: iosBridgeJS,
            injectionTime: .atDocumentStart,
            forMainFrameOnly: true
        )
        ucc.addUserScript(bridge)
        config.userContentController = ucc

        webView = WKWebView(frame: .zero, configuration: config)
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.scrollView.bounces = false
        webView.scrollView.bouncesZoom = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.scrollView.showsHorizontalScrollIndicator = false
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.backgroundColor = bgColor
        webView.isOpaque = true
        webView.uiDelegate = self
        webView.navigationDelegate = self

        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.topAnchor),
            webView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    // MARK: Load HTML
    private func loadApp() {
        guard let url = Bundle.main.url(
            forResource: "index",
            withExtension: "html",
            subdirectory: "www"
        ) else {
            showAlert("Load Error", "index.html not found in app bundle.")
            return
        }
        let wwwDir = url.deletingLastPathComponent()
        webView.loadFileURL(url, allowingReadAccessTo: wwwDir)
    }

    // MARK: iOS Bridge JavaScript
    private var iosBridgeJS: String {
        """
        (function () {
            'use strict';

            // ── Export backup: intercept <a download> clicks ──────────────
            const _origCreate = document.createElement.bind(document);
            document.createElement = function (tag) {
                const el = _origCreate(tag);
                if (tag && tag.toLowerCase() === 'a') {
                    const _origClick = el.click.bind(el);
                    el.click = function () {
                        if (el.download && el.href) {
                            const href = el.href;
                            const name = el.download || 'backup.json';
                            if (href.startsWith('blob:') || href.startsWith('data:')) {
                                fetch(href)
                                    .then(function (r) { return r.text(); })
                                    .then(function (text) {
                                        window.webkit.messageHandlers.exportBackup
                                            .postMessage({ data: text, filename: name });
                                    })
                                    .catch(function () { _origClick(); });
                                return;
                            }
                        }
                        _origClick();
                    };
                }
                // ── Import backup: intercept <input type=file> clicks ──────
                if (tag && tag.toLowerCase() === 'input') {
                    const _origInputClick = el.click.bind(el);
                    el.click = function () {
                        if (el.type === 'file') {
                            window.webkit.messageHandlers.importBackup.postMessage({});
                            return;
                        }
                        _origInputClick();
                    };
                }
                return el;
            };
        })();
        """
    }
}

// MARK: - WKScriptMessageHandler
extension ViewController: WKScriptMessageHandler {

    func userContentController(
        _ userContentController: WKUserContentController,
        didReceive message: WKScriptMessage
    ) {
        switch message.name {
        case "exportBackup": handleExport(message.body)
        case "importBackup": handleImport()
        default: break
        }
    }

    // MARK: Export
    private func handleExport(_ body: Any) {
        guard
            let dict = body as? [String: Any],
            let text = dict["data"] as? String,
            let name = dict["filename"] as? String
        else { return }

        let tmp = FileManager.default.temporaryDirectory.appendingPathComponent(name)
        do {
            try text.write(to: tmp, atomically: true, encoding: .utf8)
        } catch {
            showAlert("Export Failed", "Could not write backup file: \(error.localizedDescription)")
            return
        }

        let vc = UIActivityViewController(activityItems: [tmp], applicationActivities: nil)
        vc.popoverPresentationController?.sourceView = view
        vc.popoverPresentationController?.sourceRect = CGRect(
            x: view.bounds.midX, y: view.bounds.midY, width: 0, height: 0
        )
        present(vc, animated: true)
    }

    // MARK: Import
    private func handleImport() {
        var types: [UTType] = [.json]
        if let t = UTType(mimeType: "application/json") { types = [t] }
        let picker = UIDocumentPickerViewController(forOpeningContentTypes: types)
        picker.delegate = self
        picker.allowsMultipleSelection = false
        present(picker, animated: true)
    }

    // MARK: Helpers
    private func showAlert(_ title: String, _ msg: String) {
        let a = UIAlertController(title: title, message: msg, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default))
        present(a, animated: true)
    }
}

// MARK: - UIDocumentPickerDelegate
extension ViewController: UIDocumentPickerDelegate {

    func documentPicker(
        _ controller: UIDocumentPickerViewController,
        didPickDocumentsAt urls: [URL]
    ) {
        guard let url = urls.first else { return }
        guard url.startAccessingSecurityScopedResource() else {
            showAlert("Import Failed", "Permission denied for the selected file.")
            return
        }
        defer { url.stopAccessingSecurityScopedResource() }

        do {
            let text = try String(contentsOf: url, encoding: .utf8)
            // Use base64 to safely pass arbitrary JSON into JS without escape issues
            guard let b64 = text.data(using: .utf8)?.base64EncodedString() else {
                showAlert("Import Failed", "Could not encode backup data.")
                return
            }
            let js = """
            (function () {
                try {
                    var raw = atob('\(b64)');
                    var data = JSON.parse(raw);
                    if (!data || !Array.isArray(data.flights)) {
                        alert('This backup file is not valid.');
                        return;
                    }
                    saveFlights(data.flights);
                    if (typeof stats === 'function') { stats(); }
                    alert('Backup imported successfully.');
                } catch (e) {
                    alert('This backup file is not valid: ' + e.message);
                }
            })();
            """
            webView.evaluateJavaScript(js, completionHandler: nil)
        } catch {
            showAlert("Import Failed", "Could not read the file: \(error.localizedDescription)")
        }
    }
}

// MARK: - WKUIDelegate (alert/confirm/prompt dialogs)
extension ViewController: WKUIDelegate {

    func webView(
        _ webView: WKWebView,
        runJavaScriptAlertPanelWithMessage message: String,
        initiatedByFrame frame: WKFrameInfo,
        completionHandler: @escaping () -> Void
    ) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler() })
        present(a, animated: true)
    }

    func webView(
        _ webView: WKWebView,
        runJavaScriptConfirmPanelWithMessage message: String,
        initiatedByFrame frame: WKFrameInfo,
        completionHandler: @escaping (Bool) -> Void
    ) {
        let a = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(false) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in completionHandler(true) })
        present(a, animated: true)
    }

    func webView(
        _ webView: WKWebView,
        runJavaScriptTextInputPanelWithPrompt prompt: String,
        defaultText: String?,
        initiatedByFrame frame: WKFrameInfo,
        completionHandler: @escaping (String?) -> Void
    ) {
        let a = UIAlertController(title: nil, message: prompt, preferredStyle: .alert)
        a.addTextField { tf in tf.text = defaultText }
        a.addAction(UIAlertAction(title: "Cancel", style: .cancel) { _ in completionHandler(nil) })
        a.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            completionHandler(a.textFields?.first?.text)
        })
        present(a, animated: true)
    }
}

// MARK: - WKNavigationDelegate
extension ViewController: WKNavigationDelegate {

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        // Ensure status bar area matches app background on devices without notch
        let js = """
        document.documentElement.style.setProperty(
            '--status-bar-height',
            '\(UIApplication.shared.windows.first?.safeAreaInsets.top ?? 0)px'
        );
        """
        webView.evaluateJavaScript(js, completionHandler: nil)
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        print("[Badr] Navigation error: \(error.localizedDescription)")
    }

    // Block external navigation (app is offline-only)
    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        if let url = navigationAction.request.url, url.isFileURL {
            decisionHandler(.allow)
        } else if navigationAction.navigationType == .other {
            decisionHandler(.allow)
        } else {
            decisionHandler(.cancel)
        }
    }
}
