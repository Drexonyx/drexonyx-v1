# Badr Airlines Flight Logbook — iOS Xcode Project

Native iOS wrapper for the BADR AIRLINES crew flight logbook (Hani Elhassan · ID 1381).

## What this is

A WKWebView shell app that loads the approved, self-contained HTML/PWA from the app bundle.
All UI, data, and employee identity live in `BadrAirlinesFlightLogbook/www/index.html`.

- Bundle ID: `com.badrairlines.flightlogbook`
- Version: 1.0 (build 1)
- Minimum iOS: 15.0
- Device: iPhone only, portrait

## How to build

1. Open `BadrAirlinesFlightLogbook.xcodeproj` in Xcode 15 or later.
2. Select your Apple Developer Team in **Signing & Capabilities → Team**.
3. Choose a real device or simulator target.
4. Press **⌘R** (Run) to build and install.

To produce an IPA for distribution:
- **Product → Archive**, then **Distribute App** from the Organizer.
- Requires a paid Apple Developer account and the appropriate provisioning profile.

## Project structure

```
BadrAirlinesFlightLogbook/
├── BadrAirlinesFlightLogbook.xcodeproj/
│   └── project.pbxproj
└── BadrAirlinesFlightLogbook/
    ├── AppDelegate.swift
    ├── SceneDelegate.swift
    ├── ViewController.swift        ← WKWebView shell + iOS bridge
    ├── Info.plist
    ├── LaunchScreen.storyboard
    ├── Assets.xcassets/
    │   ├── AppIcon.appiconset/     ← 512 px placeholder; replace for App Store
    │   └── AccentColor.colorset/
    └── www/                        ← copied verbatim from approved build
        ├── index.html              ← 1.4 MB self-contained PWA
        ├── hero.png
        ├── icon-512.png
        ├── sw.js
        └── manifest.webmanifest
```

## iOS bridge — what ViewController.swift does

| HTML action | iOS bridge intercept | Native result |
|---|---|---|
| `<a download>` click | `document.createElement` override | `UIActivityViewController` share sheet |
| `<input type=file>` click | `document.createElement` override | `UIDocumentPickerViewController` (.json) |
| `alert()` / `confirm()` / `prompt()` | `WKUIDelegate` | Native `UIAlertController` |

Data is persisted via `WKWebsiteDataStore.default()`, which maps to the device's
permanent localStorage/IndexedDB — survives app restarts and OS updates.

## Signing note

IPA production requires an Apple Developer account (free or paid).
The project ships with `CODE_SIGN_STYLE = Automatic` and `DEVELOPMENT_TEAM = ""`
so Xcode will prompt you to choose your team on first open.
No code changes are needed — signing is the only remaining step.
